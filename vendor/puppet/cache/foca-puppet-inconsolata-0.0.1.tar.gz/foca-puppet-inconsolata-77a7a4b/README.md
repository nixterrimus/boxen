# Inconsolata

Installs the [Inconsolata][] font family into your system.

## Usage:

``` puppet
include inconsolata
```

## Required Puppet Modules

* `boxen`

[Inconsolata]: http://levien.com/type/myfonts/inconsolata.html
